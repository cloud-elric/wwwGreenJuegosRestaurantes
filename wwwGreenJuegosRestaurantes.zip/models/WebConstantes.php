<?php
namespace app\models;

class WebConstantes{
    const ENTRE_FUEGOS = 1;
    const LA_3RA_RONDA = 2;
    const LA_TEXTILERIA = 3;
    const SONORAS = 4;

    const DOS_POR_UNO = 2;
    const DESCUENTO = 7;

    const TIEMPO_PREMIO_MAYOR = "120";
    const TEST = NULL;
}