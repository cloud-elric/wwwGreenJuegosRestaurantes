<?php
/*return [
    'class' =>'yii\db\Connection',
    'dsn' => 'mysql:host=184.154.216.243;dbname=gomcommx_green-katedra',
    'username' => 'gomcommx_GeekDeveloper',
    'password' => 'c0d1ngG33k',
    'charset' => 'utf8',
];*/
return [
    'class' =>'yii\db\Connection',
    'dsn' => 'mysql:host=184.154.216.243;dbname=gomcommx_green-juegos-restaurantes',
   'username' => 'gomcommx_GeekDeveloper',
    'password' => 'c0d1ngG33k',
    'charset' => 'utf8',
];
